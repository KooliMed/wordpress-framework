function hidekmmsg(){
    document.getElementById('kmmsg').style.display = 'none';
}
