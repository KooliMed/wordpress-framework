<?php
if (!defined('ABSPATH')) {
    exit;
}
echo 'Hello This is your first admin page. <br>You can change my content in this file: '.__FILE__;
echo '<br>You can create as many pages as you need, just creating there output and uploading them into the same folder. The plugin will automaticaly add them to the plugin submenu and display them as they are.'
?>