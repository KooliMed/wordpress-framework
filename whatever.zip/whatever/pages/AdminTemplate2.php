<?php
if (!defined('ABSPATH')) {
    exit;
}
echo 'Hello This is another admin page. <br>You can change my content in this file: ' . __FILE__;
